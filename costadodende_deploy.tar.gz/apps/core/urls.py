from django.urls import path

from .views import HomeView, LandingPageView, root_redirect

app_name = 'core'

urlpatterns = [
    path('', root_redirect, name='root'),
    path('inicio/', HomeView.as_view(), name='home'),
    path('sobre/', LandingPageView.as_view(), name='landing'),
]
