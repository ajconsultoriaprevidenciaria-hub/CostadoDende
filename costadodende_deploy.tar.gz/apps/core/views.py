from django.shortcuts import redirect
from django.views.generic import TemplateView


class HomeView(TemplateView):
	template_name = 'core/home.html'


class LandingPageView(TemplateView):
	template_name = 'core/landing.html'


def root_redirect(request):
	if request.user.is_authenticated:
		return redirect('dashboard:index')
	return LandingPageView.as_view()(request)
